import 'package:buddies/main.dart';
import 'package:flutter/material.dart';
import 'AccountPage.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final Color arrowColor;
  final bool isAccountPage;

  CustomAppBar({
    this.title = 'Events',
    this.arrowColor = Colors.white,
    this.isAccountPage = false,
  });

  @override
  Size get preferredSize => Size.fromHeight(kToolbarHeight + 16.0);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.fromLTRB(16.0, 0.0, 16.0, 8.0),
      child: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              title,
              style: TextStyle(
                color: Colors.white,
                fontSize: 30,
                fontWeight: FontWeight.bold,
              ),
            ),
            // Affichage de l'icône utilisateur sauf si on est sur la page Account
            if (!isAccountPage)
              GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => AccountPage()),
                  );
                },
                child: Image.asset(
                  'assets/user-modified.png',
                  height: 30,
                  width: 30,
                ),
              ),
          ],
        ),
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back, // Icône flèche
            color: arrowColor,
          ),
          onPressed: () {
            if (Navigator.canPop(context)) {
              Navigator.pop(context);
            } else {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => MyHomePage()), // Page d'événements ou une page valide
              );
            }
          },
        ),
      ),
    );
  }
}

class ImageCard extends StatelessWidget {
  final String image;
  final String title;
  final Color titleBackgroundColor;

  const ImageCard({
    Key? key,
    required this.image,
    required this.title,
    this.titleBackgroundColor = Colors.black87,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 350,
      height: 200,
      child: Card(
        elevation: 5,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        shadowColor: Color.fromRGBO(224, 130, 251, 0.1),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Color.fromRGBO(224, 130, 251, 0.1),
                blurRadius: 15,
                spreadRadius: 20,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: Stack(
            alignment: Alignment.bottomCenter,
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.network(
                  image,
                  width: double.infinity,
                  height: 200,
                  fit: BoxFit.cover,
                  loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                    if (loadingProgress == null) {
                      return child;
                    } else {
                      return Center(
                        child: CircularProgressIndicator(
                          value: loadingProgress.expectedTotalBytes != null
                              ? loadingProgress.cumulativeBytesLoaded /
                              (loadingProgress.expectedTotalBytes ?? 1)
                              : null,
                        ),
                      );
                    }
                  },
                  errorBuilder: (BuildContext context, Object error, StackTrace? stackTrace) {
                    return Center(child: Icon(Icons.error, color: Colors.red));
                  },
                ),
              ),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                color: titleBackgroundColor.withOpacity(0.7),
                child: Text(
                  title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.normal,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class EventMain extends StatelessWidget {
  final List? events;

  const EventMain({Key? key, this.events}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Color.fromRGBO(71, 18, 89, 1),
                  Color.fromRGBO(20, 20, 20, 1)
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
            child: Center(
              child: (events ?? []).isEmpty
                  ? Text(
                'No events available.',
                style: TextStyle(color: Colors.white, fontSize: 18),
              )
                  : SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(height: MediaQuery.of(context).padding.top + MediaQuery.of(context).size.height * 0.025),
                    ...(events ?? []).take(3).map((event) {
                      return Column(
                        children: [
                          ImageCard(
                            image: event['image'],
                            title: event['name'],
                          ),
                          SizedBox(height: 10),
                        ],
                      );
                    }).toList(),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            top: MediaQuery.of(context).size.height * 0.015,
            left: 0,
            right: 0,
            child: CustomAppBar(title: "Shows"),
          ),
        ],
      ),
    );
  }
}
