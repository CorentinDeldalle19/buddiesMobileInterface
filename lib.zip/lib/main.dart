import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:intl/intl.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'Event.dart';
import 'EventMain.dart';
import 'MessagesPage.dart';
import 'AccountPage.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Intl.defaultLocale = 'fr_FR'; // Définit la locale par défaut
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      debugShowCheckedModeBanner: false,
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('fr', 'FR'),
      ],
      home: const MyHomePage(),
    );
  }
}

class CustomBottomNavBar extends StatelessWidget {
  final int currentIndex;
  final Function(int) onTap;

  const CustomBottomNavBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      backgroundColor: const Color.fromRGBO(20, 20, 20, 1),
      currentIndex: currentIndex,
      onTap: onTap,
      items: [
        BottomNavigationBarItem(
          icon: Image.asset('assets/home-modified.png', width: 24, height: 24),
          label: ' ',
        ),
        BottomNavigationBarItem(
          icon: Image.asset('assets/festival-modified.png', width: 24, height: 24),
          label: ' ',
        ),
        BottomNavigationBarItem(
          icon: Image.asset('assets/messenger-modified.png', width: 24, height: 24),
          label: ' ',
        ),
        BottomNavigationBarItem(
          icon: Image.asset('assets/user-modified.png', width: 24, height: 24),
          label: ' ',
        ),
      ],
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _selectedIndex = 0;
  List<Widget> _pages = [];

  @override
  void initState() {
    super.initState();
    _fetchEvents();
  }

  String formatDateToDayMonth(String dateStr) {
    try {
      final dateTime = DateTime.parse(dateStr);
      final formatter = DateFormat('d MMMM', 'fr_FR');
      return formatter.format(dateTime);
    } catch (e) {
      print('Erreur de parsing de date : $e');
      return "Date inconnue";
    }
  }

  Future<void> _fetchEvents() async {
    try {
      final dio = Dio();
      print('Calling API...');
      final response = await dio.get('https://backendbuddies-production.up.railway.app/api/events');

      if (response.statusCode == 200) {
        final events = response.data as List;
        print('Fetched events: $events');

        setState(() {
          _pages = [
            Event(
              eventId: events[0]['id'].toString(),
              title: events[0]['name'] ?? "Nom inconnu",
              subtitle: "En concert à ${events[0]['location'] ?? "Lieu inconnu"} !",
              description: events[0]['description'] ?? "Pas de description disponible.",
              date: "🗓️ ${events[0]['date'] != null ? formatDateToDayMonth(events[0]['date']) : "Date inconnue"}",
              image: events[0]['image'] ?? 'assets/default-image.jpg',
              location: events[0]['location'] ?? "Inconnu",
              styleOfMusic: events[0]['style_of_music'] ?? "Inconnu",
              type: events[0]['type'] ?? "Inconnu",
            ),
            EventMain(events: events),
            MessagesPage(),
            AccountPage(),
          ];
        });
      } else {
        print('API returned with status code: ${response.statusCode}');
      }
    } catch (e) {
      print('Error fetching events: $e');
      setState(() {
        _pages = [
          Event(
            eventId: "Inconnu",
            title: "Erreur de récupération d'événement",
            subtitle: "Aucune donnée disponible.",
            description: "Erreur lors de la récupération des événements.",
            date: "🗓️ Inconnue",
            image: 'assets/default-image.jpg',
            location: "Inconnu",
            styleOfMusic: "Inconnu",
            type: "Inconnu",
          ),
          EventMain(events: []),
          MessagesPage(),
          AccountPage(),
        ];
      });
    }
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color.fromRGBO(71, 18, 89, 1),
              Color.fromRGBO(20, 20, 20, 1)
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: _pages.isNotEmpty
            ? _pages[_selectedIndex]
            : const Center(child: CircularProgressIndicator()),
      ),
      bottomNavigationBar: CustomBottomNavBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }
}